﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mandado_LockerSystem
{
    public partial class Records : Form
    {
        public string sql = "";
        OleDbConnection connRec;
        OleDbCommand cmd;
        public Records()
        {
            InitializeComponent();
        }
        
        private void Records_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'recordsDataSet.records' table. You can move, or remove it, as needed.
            this.recordsTableAdapter.Fill(this.recordsDataSet.records);
            GetStudents();

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            clearfields();
            Records_Load(sender, e);
        }

        private void clearfields()
        {
            txtLockerNo.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtCourseYear.Text = "";
            txtDaysRented.Text = "";
            txtTotal.Text = "";
            cmbPaymentStatus.Text = "";
            dtDatePaid.Text = DateTime.Now.ToString();

        }

        void GetStudents()
        {
            connRec = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source = \"C:\\Locker System MANDADO\\Mandado-LockerSystem\\bin\\Debug\\records.accdb\"");
            DataTable dtRec = new DataTable();
            OleDbDataAdapter adapRec = new OleDbDataAdapter("SELECT * FROM records", connRec);
            connRec.Open();
            adapRec.Fill(dtRec);
            dgvRecords.DataSource = dtRec;
            connRec.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO records (lockerNo,firstName, lastName, courseYear,daysRented,totalPayment,paymentStatus,datePaid) VALUES" +
                               "(@lockerNo,@firstName, @lastName, @courseYear,@daysRented,@totalPayment,@paymentStatus,@datePaid)";
            cmd = new OleDbCommand(query, connRec);
            cmd.Parameters.AddWithValue("@lockerNo", Convert.ToInt32(txtLockerNo.Text));
            cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
            cmd.Parameters.AddWithValue("@courseYear", txtCourseYear.Text);
            cmd.Parameters.AddWithValue("@daysRented", Convert.ToInt32(txtDaysRented.Text));
            cmd.Parameters.AddWithValue("@totalPayment", Convert.ToInt32(txtTotal.Text));
            cmd.Parameters.AddWithValue("@paymentStatus", cmbPaymentStatus.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@datePaid", dtDatePaid.Value.ToString("yyyy-MM-dd"));
            connRec.Open();
            cmd.ExecuteNonQuery();
            connRec.Close();
            MessageBox.Show("Inserted Successfully.");
            GetStudents();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "UPDATE records " +
                               "SET firstName=@firstName, lastName=@lastName, courseYear=@courseYear, " +
                               "daysRented=@daysRented, totalPayment=@totalPayment, " +
                               "paymentStatus=@paymentStatus, datePaid=@datePaid " +
                               "WHERE lockerNo=@lockerNo";

                cmd = new OleDbCommand(query, connRec);
                cmd.Parameters.AddWithValue("@lockerNo", Convert.ToInt32(txtLockerNo.Text));
                cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
                cmd.Parameters.AddWithValue("@courseYear", txtCourseYear.Text);
                cmd.Parameters.AddWithValue("@daysRented", Convert.ToInt32(txtDaysRented.Text));
                cmd.Parameters.AddWithValue("@totalPayment", Convert.ToInt32(txtTotal.Text));
                cmd.Parameters.AddWithValue("@paymentStatus", cmbPaymentStatus.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@datePaid", dtDatePaid.Value.ToString("yyyy-MM-dd"));

                connRec.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                connRec.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Updated successfully.");
                    GetStudents();
                }
                else
                {
                    MessageBox.Show("No records updated. Please check the provided locker number.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Display a confirmation dialog
            DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check if the user clicked Yes
            if (result == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM records WHERE lockerNo=@lockerNo";

                    cmd = new OleDbCommand(query, connRec);
                    cmd.Parameters.AddWithValue("@lockerNo", Convert.ToInt32(txtLockerNo.Text));

                    connRec.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    connRec.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record deleted successfully.");
                        GetStudents(); 
                    }
                    else
                    {
                        MessageBox.Show("No records deleted. Please check the provided locker number.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string searchText = txtSearch.Text;
                string query = "SELECT * FROM records WHERE firstName LIKE @searchText OR lastName LIKE @searchText";

                cmd = new OleDbCommand(query, connRec);
                cmd.Parameters.AddWithValue("@searchText", "%" + searchText + "%");

                connRec.Open();
                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);

                    dgvRecords.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No matching records found.");
                }

                connRec.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
}
